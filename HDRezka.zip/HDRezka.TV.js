﻿/**
 *  HDRezka.TV plugin for Movian
 *
 *  Copyright (C) 2014-2022 Buksa (fix by kovalDN)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
// ver. 2.6.8.1
//~/* eslint-disable camelcase */
//~/* eslint-disable new-cap */
/* eslint-disable require-jsdoc */
/* eslint-disable max-len */
/* eslint-disable no-var */
//(function (plugin) {
var pluginDescriptor = JSON.parse(Plugin.manifest);
var plugin = JSON.parse(Plugin.manifest);
//var pluginDescriptor = plugin.getDescriptor();
/*
var config = {
  pluginInfo: plugin.getDescriptor(),
  PREFIX: plugin.getDescriptor().id,
  TTL: plugin.getDescriptor().title,
  SYN: plugin.getDescriptor().synopsis,
  AUT: plugin.getDescriptor().author,
  VER: plugin.getDescriptor().version,
  LOGO: Plugin.path + 'HDRezka.TV.png',
};
*/
//var PREFIX = plugin.getDescriptor().id;
var PREFIX = plugin.id;
//var TTL = plugin.getDescriptor().title;
var TTL = plugin.title;
//var SYN = plugin.getDescriptor().synopsis;
var SYN = plugin.synopsis;
//var AUT = plugin.getDescriptor().author;
var AUT = plugin.author;
//var VER = plugin.getDescriptor().version;
var VER = plugin.version;
//var LOGO = Plugin.path + 'HDRezka.TV.png';
var LOGO = Plugin.path + plugin.icon;
var LOGOBACKGROUND = Plugin.path + 'src/back.jpg';
var LOGOARROW = Plugin.path + 'src/arrow.png';
//var LOGOFOLDER = Plugin.path + 'src/folder.png';
//var LOGOICON = Plugin.path + 'src/icon.png';
//var LOGOBOOKMARKS = Plugin.path + 'src/bookmarks.png';
//var LOGOEXIT = Plugin.path + 'src/exit.png';
//var LOGO1080 = Plugin.path + 'src/1080.png';
//var LOGO720 = Plugin.path + 'src/720.png';
//var LOGONONE = Plugin.path + 'src/none.png';
//var LOGO4K = Plugin.path + 'src/4k.png';
//var listview = Plugin.path + 'src/list.view';
var NAME = 'hdrezka';
//var service = require('showtime/service');
var service = require('movian/service');
//var service = plugin.createService(config.TTL, config.PREFIX + ':start', 'video', true, config.LOGO);
//var service = plugin.createService(TTL, PREFIX + ':start', 'video', true, LOGO);
//require('showtime/service').create(TTL, PREFIX + ':start', 'video', true, LOGO);
//require('movian/service').create(TTL, PREFIX + ':start', 'video', true, LOGO);
service.create(TTL, PREFIX + ':start', 'video', true, LOGO);
//var storage = plugin.createStore(NAME);
//var store = plugin.createStore('config', true);
var io = require('native/io');
var popup = require('native/popup');
//var prop = require('showtime/prop');
var prop = require('movian/prop');
//var page = require('showtime/page');
var page = require('movian/page');
//var http = require('showtime/http');
var http = require('movian/http');
//var html = require('showtime/html');
var html = require('movian/html');
//var html = 0;
var urls = require('url');
//var UA = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
//var UA = 'Mozilla/5.0 (Windows NT 10.0; rv:80.0) Gecko/20100101 Firefox/80.0';
//var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36';
//var UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36';
//var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36';
//var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36';
//var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36';
var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36';
var result = '';
var data = {};
var items = [];
var api = require('./src/api');
var browse = require('./src/browse');
var log = require('./src/log');
var moviepage = require('./src/moviepage');
var DeanEdwardsUnpacker = require('./utils/Dean-Edwards-Unpacker').unpacker;
var atob = require('./utils/atob');
var btoa = require('./utils/btoa');
/*
var config = {
  headers: {
  },
};
*/
/*
var config = {
  regExps: {
  },
};
*/
/*
var config = {
  colors: {
    blue: '6699CC',
    orange: 'FFA500',
    red: 'EE0000',
//    green: '008B45',
    green: '66FF72',
    yellow: 'FFFF00',
    gray: '555555',
  },
};
*/
var blue = '6699CC';
var orange = 'FFA500';
var red = 'EE0000';
//var green = '008B45';
var green = '66FF72';
var yellow = 'FFFF00';
var gray = '555555';
function colorStr(str, color) {
  return '<font color="' + color + '"> (' + str + ')</font>';
//  return '<font color="' + color + '"> ' + str + '</font>';
};
function coloredStr(str, color) {
  return '<font color="' + color + '">' + str + '</font>';
};
RichText = function (x) {this.str = x.toString()};
RichText.prototype.toRichString = function (x) {return this.str};
function getStringFromArray(obj) {
  var str = '';
  obj.forEach(function (data, index) {
    str = str + data.name + ',';
  });
  return str.substring(0, str.length - 1);
};
//var settings = require('showtime/settings');
var settings = require('movian/settings');
//var settings = plugin.createSettings(config.TTL, config.LOGO, config.PREFIX, config.SYN);
//var settings = plugin.createSettings(TTL, LOGO, PREFIX, SYN);
//settings.globalSettings(TTL, LOGO, PREFIX, SYN);
settings.globalSettings(PREFIX, TTL, LOGO, SYN);
//settings.createInfo('info', config.LOGO, 'Plugin developed by ' + config.AUT + '. \n');
//settings.createInfo('info', LOGO, 'Plugin developed by ' + AUT + '. \n');
settings.createInfo('info', LOGO, 'Plugin developed by ' + AUT + ', \n' + PREFIX + ', \n' + 'ver. ' + VER + ' \n');
//settings.createDivider('Settings:');
settings.createDivider('Настройки:');
//settings.createBool('tosaccepted', 'Accepted TOS (available in opening the plugin)', true, function (v) {service.tosaccepted = v});
//settings.createBool('tosaccepted', 'Accepted TOS (available in opening the plugin)', false, function (v) {service.tosaccepted = v});
//settings.createBool('tosaccepted', 'Принятие условий использования (при открытии плагина)', true, function (v) {service.tosaccepted = v});
settings.createBool('tosaccepted', 'Принятие условий использования (при открытии плагина)', false, function (v) {service.tosaccepted = v});
//var tos = 'The developer has no affiliation with the sites what so ever.\n';
//tos += 'Nor does he receive money or any other kind of benefits for them.\n\n';
//tos += 'The software is intended solely for educational and testing purposes,\n';
//tos += 'and while it may allow the user to create copies of legitimately acquired\n';
//tos += 'and/or owned content, it is required that such user actions must comply\n';
//tos += 'with local, federal and country legislation.\n\n';
//tos += 'Furthermore, the author of this software, its partners and associates\n';
//tos += 'shall assume NO responsibility, legal or otherwise implied, for any misuse\n';
//tos += 'of, or for any loss that may occur while using plugin.\n\n';
//tos += 'You are solely responsible for complying with the applicable laws in your\n';
//tos += 'country and you must cease using this software should your actions during\n';
//tos += 'plugin operation lead to or may lead to infringement or violation of the\n';
//tos += 'rights of the respective content copyright holders.\n\n';
//tos += 'plugin is not licensed, approved or endorsed by any online resource\n ';
//tos += 'proprietary. Do you accept this terms?';
//var tos = 'Разработчик не имеет никакого отношения к сайтам, что бы это ни было. Он также не получает за это денег или каких-либо иных льгот. Программное обеспечение предназначено исключительно для образовательных и тестовых целей, и, хотя оно может позволить пользователю создавать копии законно приобретенного и/или принадлежащего контента, требуется, чтобы такие действия пользователя соответствовали законодательству . Кроме того, автор этого программного обеспечения и его партнеры не несут НИКАКОЙ ответственности, юридической или иной подразумеваемой, за любое неправильное использование или за любые убытки, которые могут возникнуть при использовании плагина. Вы несете единоличную ответственность за соблюдение применимых законов в вашей стране, и вы должны прекратить использование этого программного обеспечения, если ваши действия во время работы плагина приведут или могут привести к нарушению прав соответствующих владельцев авторских прав на контент или к каким-либо иным нарушениям . Плагин не лицензирован, не признан и не одобрен каким-либо интернет-ресурсом, являющимся собственностью компании.\n\n';
var tos = 'Плагин предназначен исключительно для образовательных и тестовых целей. Разработчики плагина не имеют отношения к данным сайтам и интернет-ресурсам, не получают каких-либо денег или иных льгот, не несут НИКАКОЙ ответственности за любые действия при использовании плагина. Вы несете единоличную ответственность за соблюдение применимого законодательства и должны прекратить использование плагина, если ваши действия приведут или могут привести к каким-либо нарушениям законодательства.\n\n';
tos += 'Принимаете ли вы эти условия использования?';
//settings.createBool('debug', 'Отладка (debug)', true, function (v) {store.debug = v});
//settings.createBool('debug', 'Отладка (debug)', false, function (v) {store.debug = v});
//settings.createBool('debug', 'Debug', true, function (v) {service.debug = v});
//settings.createBool('debug', 'Debug', false, function (v) {service.debug = v});
//settings.createBool('debug', 'Отладка (debug)', true, function (v) {service.debug = v});
settings.createBool('debug', 'Отладка (debug)', false, function (v) {service.debug = v});
function printDebug(message) {
//  if (store.debug) console.error(message);
  if (service.debug) console.error(message);
};
//settings.createString('baseURL', 'Base URL (without "/" at the end)', BASE_URL, function (v) {service.baseURL = v});
//settings.createString('baseURL', 'Базовый URL (без завершающего "/")', BASE_URL, function (v) {service.baseURL = v});
//settings.createString('domain', 'Base URL (without "/" at the end)', 'https://rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Базовый URL (без завершающего "/")', 'https://rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Domain', 'https://rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Домен', 'https://rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', '\u0414\u043e\u043c\u0435\u043d', 'http://hdrezkayou.com', function (v) {service.domain = v});
//settings.createString('domain', 'Домен', 'rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без "http://" и завершающего "/" в конце)', 'rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'http://rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без "https://" и завершающего "/" в конце)', 'rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'https://rezka.ag', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'http://hdrezkayou.com', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'http://aghdrezka.com', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'http://metaivi.com', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'http://cokinopoisk.com', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'http://kinopub.me', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'http://rezkify.com', function (v) {service.domain = v});
//settings.createString('domain', 'Домен (базовый URL без завершающего "/" в конце)', 'https://rezkify.com', function (v) {service.domain = v});
//settings.createString('domain1', 'Домен (партнерский URL без завершающего "/" в конце)', 'http://8.8.8.8', function (v) {service.domain1 = v});
//settings.createString('domain1', 'Домен (партнерский URL без завершающего "/" в конце)', 'http://rezka.ag', function (v) {service.domain1 = v});
settings.createString('domain0', 'Домен (базовый URL без завершающего "/" в конце)', 'http://hdrezkayou.com', function (v) {service.domain0 = v});
settings.createMultiOpt('domain', 'Выбор домена', [
//  [service.domain1 + '/partner_api', service.domain1],
//  [service.domain1 + '/partner_api', service.domain1, true],
//  [service.domain1 + '/solr', service.domain1],
//  [service.domain1 + '/solr', service.domain1, true],
//  [service.domain0, service.domain0],
  [service.domain0, service.domain0, true],
//  ['http://8.8.8.8' + '/partner_api', 'http://8.8.8.8'],
//  ['http://rezka.ag' + '/solr', 'http://rezka.ag'],
  ['https://rezkify.com', 'https://rezkify.com'],
  ['http://rezkify.com', 'http://rezkify.com'],
  ['http://kinopub.me', 'http://kinopub.me'],
  ['http://cokinopoisk.com', 'http://cokinopoisk.com'],
  ['http://metaivi.com', 'http://metaivi.com'],
  ['http://aghdrezka.com', 'http://aghdrezka.com'],
  ['http://hdrezkayou.com', 'http://hdrezkayou.com'],
  ['http://rezka.ag', 'http://rezka.ag'],
  ['https://rezka.ag', 'https://rezka.ag'],
  ],
  function (v) {
//  printDebug('set domain to ' + v);
  printDebug('Установите домен на ' + v);
  service.domain = v;
});
//var BASE_URL = 'http://rezka.ag';
var BASE_URL = service.domain;
/*
//settings.createBool('noblock', 'Анонимайзер NoBlockMe', true, function (v) {
settings.createBool('noblock', 'Анонимайзер NoBlockMe', false, function (v) {
  service.noblock = v;
  log.d(service);
});
30
if (service.noblock) {
  var resp = http.request('http://noblockme.ru/api/anonymize?url=' + service.domain, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 OPR/73.0.3856.424',
//!~del''      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*''/''*;q=0.8,application/signed-exchange;v=b3;q=0.9',
//      'Accept-Encoding': 'gzip, deflate',
      'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    },
  }).toString();
  var BASE_URL = JSON.parse(resp).result.match(/(.*)\//)[1];
  var resp = http.request(BASE_URL, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 OPR/73.0.3856.424',
//!~del''      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*''/''*;q=0.8,application/signed-exchange;v=b3;q=0.9',
//      'Accept-Encoding': 'gzip, deflate',
      'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    },
  }).toString();
}
else BASE_URL = service.domain;
*/
/*
function sendRequest(url) {
  var token_def = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiIsImp0aSI6ImZ4LTVlYjg3NzgwMjY5MWMifQ.eyJpc3MiOiJodHRwczpcL1wvZmlsbWl4Lm1lIiwiYXVkIjoiaHR0cHM6XC9cL2ZpbG1peC5tZSIsImp0aSI6ImZ4LTVlYjg3NzgwMjY5MWMiLCJpYXQiOjE1ODkxNDc1MjAsIm5iZiI6MTU4OTEzNjcyMCwiZXhwIjoxNTkxNzM5NTIwLCJwYXJ0bmVyX2lkIjoiMiIsImhhc2giOiJiOTMwZDhjMGMzOTE5ZDZkNDBjYWE4ZWExODY0ODFmODVjNGVlNjA4IiwidXNlcl9pZCI6bnVsbCwiaXNfcHJvIjpmYWxzZSwiaXNfcHJvX3BsdXMiOmZhbHNlLCJzZXJ2ZXIiOiIifQ.I8NBrVlREjVA_CthL0i6GBTgR6-y7lndU5JLmhh4ejA';
  var token = token_def;	
  if (storage.expired && storage.expired > Math.floor(Date.now() /1000) && storage.token) {			
    var token = storage.token;			
  }
  var headers = {
    debug: false,
    compression: true,
    headRequest: false,
    headers: {
      'User-Agent': UA,															 
//!~del''      'accept': 'application/json, text/javascript, *''/''*; q=0.01',
      'X-FX-Token': token,
    },
  };
  return showtime.httpReq(url, headers);
};
*/
//var inspect_url = BASE_URL.replace(/^http.*(\w{4,15}.\w{2,3})$/gm,'.*\.$1') + '.*';
//print(inspect_url)
//io.httpInspectorCreate(inspect_url, function (ctrl) {
io.httpInspectorCreate('http.*load.hdrezka-ag.net.*', function (ctrl) {
//io.httpInspectorCreate('.*load.hdrezka-ag.net.*', function (ctrl) {
  ctrl.setHeader('User-Agent', UA);
//  ctrl.setHeader('Origin', 'https://rezka.ag');
//  ctrl.setHeader('Referer', 'https://rezka.ag/');
//  ctrl.setHeader('Referer', BASE_URL);
//  ctrl.setHeader('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9');
//  ctrl.setHeader('Accept-Encoding', 'gzip, deflate');
//  ctrl.setHeader('Accept-Language', 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7');
  return 0;
});
//io.httpInspectorCreate('http.*video/[a-f0-9]{16}/.*', function (ctrl) {
//  ctrl.setHeader('User-Agent', UA);
//  return 0;
//});
//io.httpInspectorCreate('http.*streamguard.cc.*', function (ctrl) {
//  ctrl.setHeader('User-Agent', UA);
//  return 0;
//});
//io.httpInspectorCreate('http.*.m3u8', function (ctrl) {
//  ctrl.setHeader('Content-Type', 'application/x-mpegURL');
//  return 0;
//});
//  'GET': '/4/6/0/8/7/3/4c......b20f3:2022010617:cHR.......kE9PQ==/o2vmz.mp4:hls:manifest.m3u8 HTTP/1.1',
//  'Host': 'stream.voidboost.cc',
//  'Connection': 'keep-alive',
//  'Pragma': 'no-cache',
//  'Cache-Control': 'no-cache',
//  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
//  'Accept': '*/*',
//  'Sec-GPC': '1',
//  'Origin': 'http://hdrezkayou.com',
//  'Referer': 'http://hdrezkayou.com/',
//  'Accept-Encoding': 'gzip, deflate',
//  'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
io.httpInspectorCreate('http.*stream.voidboost.cc.*', function (ctrl) {
  ctrl.setHeader('User-Agent', UA);
  ctrl.setHeader('Referer', referer);
  return 0;
});
//var referer = service.domain;
var referer = BASE_URL;
/*
//settings.createString('userCookie', 'Cookie user', 'DONT_TOUCH_THIS', function (v) {service.userCookie = v});
settings.createString('userCookie', 'Cookie пользователя', 'НЕ ТРОГАЙ ЭТО', function (v) {service.userCookie = v});
*/
/*
//settings.createBool('bg', 'Background', true, function (v) {service.bg = v});
//settings.createBool('bg', 'Background', false, function (v) {service.bg = v});
settings.createBool('bg', 'Задний фон', true, function (v) {service.bg = v});
//settings.createBool('bg', 'Задний фон', false, function (v) {service.bg = v});
//settings.createBool('background', 'Background', true, function (v) {service.background = v});
//settings.createBool('background', 'Background', false, function (v) {service.background = v});
//settings.createBool('background', 'Задний фон', true, function (v) {service.background = v});
//settings.createBool('background', 'Задний фон', false, function (v) {service.background = v});
*/
//settings.createBool('Show_META', 'Show more info from thetvdb', true, function (v) {service.tvdb = v});
//settings.createBool('Show_META', 'Show more info from thetvdb', false, function (v) {service.tvdb = v});
settings.createBool('Show_META', 'Показ информации из базы данных thetvdb', true, function (v) {service.tvdb = v});
//settings.createBool('Show_META', 'Показ информации из базы данных thetvdb', false, function (v) {service.tvdb = v});
/*
//settings.createBool('torrentLink', 'Torrent Link', 0, function (v) {service.torrentLink = v});
settings.createBool('torrentLink', 'Видимость Torrent-ссылок', 0, function (v) {service.torrentLink = v});
*/
/*
//settings.createString('userLanguage', 'Preferable audio track language', 'en', function (v) {service.userLanguage = v;});
//settings.createString('userLanguage', 'Предпочтительный язык звуковой дорожки', 'en', function (v) {service.userLanguage = v;});
//settings.createString('userLanguage', 'Preferable audio track language', 'uk', function (v) {service.userLanguage = v;});
//settings.createString('userLanguage', 'Предпочтительный язык звуковой дорожки', 'uk', function (v) {service.userLanguage = v;});
//settings.createString('userLanguage', 'Preferable audio track language', 'ru', function (v) {service.userLanguage = v;});
//settings.createString('userLanguage', 'Предпочтительный язык звуковой дорожки', 'ru', function (v) {service.userLanguage = v;});
settings.createString('userLanguage0', 'Предпочтительный язык звуковой дорожки', 'ru', function (v) {service.userLanguage0 = v});
settings.createMultiOpt('userLanguage', 'Выбор языка звуковой дорожки', [
//  [service.userLanguage0, service.userLanguage0],
  [service.userLanguage0, service.userLanguage0, true],
  ['ru', 'ru'],
//  ['uk', 'uk'],
  ['en', 'en'],
  ],
  function (v) {
//  printDebug('set audio track language to ' + v);
  printDebug('Установите язык звуковой дорожки на ' + v);
  service.userLanguage = v;
});
*/
//settings.createBool('cp', 'Continuous play', true, function (v) {service.cp = v});
//settings.createBool('cp', 'Continuous play', false, function (v) {service.cp = v});
//settings.createBool('cp', 'Непрерывное воспроизведение', true, function (v) {service.cp = v});
settings.createBool('cp', 'Непрерывное воспроизведение', false, function (v) {service.cp = v});
/*
settings.createDivider('Авторизация:');
*/
/*
//settings.createAction(NAME + '_login', 'Войти в ' + BASE_URL, function () {login(1, true)});
settings.createAction(NAME + '_login', 'Войти в ' + TTL + ' (' + BASE_URL + ')', function () {login(1, true)});
//var logged = true;
//var logged = true, credentials;
//var logged = false;
var logged = false, credentials;
*/
/*
if (!logged) {
//settings.createAction(NAME + '_login', 'Войти в ' + BASE_URL, function () {login(0, true)});
settings.createAction(NAME + '_login', 'Войти в ' + TTL + ' (' + BASE_URL + ')', function () {login(0, true)});
}
else {
//settings.createAction(NAME + '_login', 'Выйти из ' + BASE_URL, function () {logOut(0, true)});
settings.createAction(NAME + '_login', 'Выйти из ' + TTL + ' (' + BASE_URL + ')', function () {logOut(0, true)});
}
*/
/*
function login(page, showDialog) {
  var text = '';
  if (showDialog) {
//    text = 'Введите e-mail и пароль';
//    text = 'Требуется авторизация, введите e-mail и пароль';
//    text = 'Введите логин и пароль';
    text = 'Требуется авторизация, введите логин и пароль';
    logged = false;
  }
  if (!logged) {
//    credentials = plugin.getAuthCredentials(BASE_URL, text, showDialog);
    credentials = plugin.getAuthCredentials(TTL + ' (' + BASE_URL + ')', text, showDialog);
    if (credentials && credentials.username && credentials.password) {
      var params = 'username=' + credentials.username + '&password=' + credentials.password + '&returnto';
      page.loading = true;
      var resp = showtime.httpReq(BASE_URL + '/login.php', {
//      var resp = http.request(BASE_URL + '/login.php', {
//      noFail: true,
        postdata: {
          username: credentials.username,
          password: credentials.password,
          returnto: ''
        }
      }).toString();
      page.loading = false;
//      showtime.print(resp);
//      resp = resp.match(/<input class=buttonS/);
      resp = resp.match(/<div class='buttons'/);
//      showtime.print(resp);
      if (resp === null) logged = true;
    }
  }
  if (showDialog) {
    if (logged) showtime.message('Вход успешно произведен.\nПараметры входа сохранены.', true, false);
//    if (logged) popup.message('Вход успешно произведен.\nПараметры входа сохранены.', true, false);
//    else showtime.message('Не удалось войти.\nПроверьте e-mail/пароль.', true, false);
//    else popup.message('Не удалось войти.\nПроверьте e-mail/пароль.', true, false);
    else showtime.message('Не удалось войти.\nПроверьте логин/пароль.', true, false);
//    else popup.message('Не удалось войти.\nПроверьте логин/пароль.', true, false);
  }
};
*/
/*
function logOut() {
  showtime.message('Выход совершен.', true, false);
//  popup.message('Выход совершен.', true, false);
};
*/
/*
//settings.createString('authkey', 'Auth key', '', function (v) {service.authkey = v});
settings.createString('authkey', 'Ключ авторизации (auth key)', '', function (v) {service.authkey = v});
//settings.createString('authtoken', 'Auth token', '', function (v) {service.authToken = v});
settings.createString('authtoken', 'Токен авторизации (auth token)', '', function (v) {service.authtoken = v});
if (!storage.expired || storage.expired < Math.floor(Date.now() /1000) || !storage.token) {
//settings.createAction(NAME + '_login', 'Войти в ' + BASE_URL, function () {login(0, true)});
settings.createAction(NAME + '_login', 'Войти в ' + TTL + ' (' + BASE_URL + ')', function () {login(0, true)});
}
else {
//settings.createAction(NAME + '_login', 'Выйти из ' + BASE_URL, function () {logOut(0, true)});
settings.createAction(NAME + '_login', 'Выйти из ' + TTL + ' (' + BASE_URL + ')', function () {logOut(0, true)});
}
function login(page, showDialog) {
  var text = '';
  if (showDialog) {
//    text = 'Введите e-mail и пароль';
//    text = 'Требуется авторизация, введите e-mail и пароль';
//    text = 'Введите логин и пароль';
    text = 'Требуется авторизация, введите логин и пароль';
    var logged = false;
  }
//  if (!logged && service.authToken.length == 40) {
  if (!logged && service.authkey.length == 32 && service.authtoken.length == 40) {
//    credentials = plugin.getAuthCredentials(BASE_URL, text, showDialog);
    credentials = plugin.getAuthCredentials(TTL + ' (' + BASE_URL + ')', text, showDialog);
    if (credentials && credentials.username && credentials.password) {
      page.loading = true;
      var get_token_header = {
        debug: false,
        compression: true,
        headRequest: false,
        headers: {
          'User-Agent': UA,															 
//!~del''          'accept': 'application/json, text/javascript, *''/''*; q=0.01',															  
        },
        postdata: {
//          key: '160c907041cac0fd84c367c1e0031b67',
          key: service.authkey,
//          token: 'b930d8c0c3919d6d40caa8ea186481f85c4ee608',
          token: service.authtoken,
          user_name: credentials.username,
          user_passw: credentials.password,
        }
      };
      var reply = showtime.httpReq(BASE_URL + '/request_token', get_token_header);
      reply = showtime.JSONDecode(reply);
      page.loading = false;
      if (reply.token && reply.expired) {
        storage.token = reply.token;
        storage.expired = reply.expired;
        sendRequest(BASE_URL + '/profile/login');
        logged = true;					
      }
    }
  }
*/
/*
  else if (service.authtoken.length != 40) {
    showtime.message('Не верный формат токена авторизации (auth token).', true, false);
//    popup.message('Не верный формат токена авторизации (auth token).', true, false);
    return false;
  }
*/
/*
  else {
    if (service.authkey.length != 32) {
      showtime.message('Не верный формат ключа авторизации (auth key).\nПроверьте количество знаков.', true, false);
//      popup.message('Не верный формат ключа авторизации (auth key).\nПроверьте количество знаков.', true, false);
      return false;
    }
    if (service.authtoken.length != 40) {
      showtime.message('Не верный формат токена авторизации (auth token).\nПроверьте количество знаков.', true, false);
//      popup.message('Не верный формат токена авторизации (auth token).\nПроверьте количество знаков.', true, false);
      return false;
    }
  }
  if (showDialog) {
    if (logged) {
      showtime.message('Вход успешно произведен.\nПараметры входа сохранены.', true, false);	
//      popup.message('Вход успешно произведен.\nПараметры входа сохранены.', true, false);	
    }
    else {
//      showtime.message('Не удалось войти.\nПроверьте ключ/токен/e-mail/пароль.', true, false);
//      popup.message('Не удалось войти.\nПроверьте ключ/токен/e-mail/пароль.', true, false);
      showtime.message('Не удалось войти.\nПроверьте ключ/токен/логин/пароль.', true, false);
//      popup.message('Не удалось войти.\nПроверьте ключ/токен/логин/пароль.', true, false);
    }
  }
};
function logOut() {
  storage.token = false;
  storage.expired = false;
  showtime.message('Выход совершен.', true, false);
//  popup.message('Выход совершен.', true, false);
};
*/
/*
function login(query) {
  if (loggedIn)
  return false;
//  var reason = 'Login required';
//  var reason = 'Требуется авторизация';
//  var reason = 'Введите e-mail и пароль';
//  var reason = 'Введите логин и пароль';
//  var reason = 'Требуется авторизация, введите e-mail и пароль';
  var reason = 'Требуется авторизация, введите логин и пароль';
  var do_query = false;
  while (true) {
//    var credentials = popup.getAuthCredentials('Login ' + TTL, reason, do_query);
    var credentials = popup.getAuthCredentials('Войти в ' + TTL + ' (' + BASE_URL + ')', reason, do_query);
//    var credentials = popup.getAuthCredentials(TTL + ' (' + BASE_URL + ')', reason, do_query);
    if (!credentials) {
      if (query && !do_query) {
        do_query = true;
        continue;
      }
      reason = 'No credentials'
      return false;
    }
    if (credentials.rejected) {
      reason = 'Rejected by user',
      console.log('Rejected by use'),
      return false;
    }
    var v = http.request(BASE_URL, {
      headers: {
        'Origin': BASE_URL,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36',
//!~del''        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*''/''*;q=0.8,application/signed-exchange;v=b3',
        'Referer': BASE_URL + '/',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'ru,en-US;q=0.9,en;q=0.8,zh;q=0.7',
        'Upgrade-Insecure-Requests': 1,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cache-Control': 'max-age=0',
// -H        'Connection: keep-alive'
// -H        'Pragma: no-cache',
// -H        'Cache-Control: no-cache',
// -H        'Sec-Fetch-Mode: navigate',
// -H        'Sec-Fetch-Site: same-origin',
      },
      postdata: {
        login_name: credentials.username,
        login_password: credentials.password,
        login: 'submit',
      },
    });
    console.log(v);
    var doc = XML.parse(v).response;
    if (doc.error) {
      reason = doc.error;
      do_query = true;
      continue;
    }
//    showtime.trace('Logged in to ' + TTL + ' as user: ' + credentials.username);
    showtime.trace('Вход в ' + TTL + ' как пользователь: ' + credentials.username);
    loggedIn = true;
    return false;
  }
};
*/
/*
settings.createDivider('Дополнительный список трекеров:');
var magnetTrackers = null;
//settings.createString('trackers', 'Additional tracker list to use', 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best_ip.txt', function (v) {
//settings.createString('trackers', 'Дополнительный список трекеров для использования', 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best_ip.txt', function (v) {
settings.createString('trackers1', 'Полный путь к списку трекеров (часть 1)', 'https://raw.githubusercontent.com/', function (v) {service.trackers1 = v});
settings.createString('trackers2', 'Полный путь к списку трекеров (часть 2)', 'ngosang/trackerslist/master/', function (v) {service.trackers2 = v});
settings.createString('trackers3', 'Полный путь к списку трекеров (часть 3)', 'trackers_best_ip.txt', function (v) {service.trackers3 = v});
settings.createString('trackers', 'Список трекеров для использования', service.trackers1 + service.trackers2 + service.trackers3, function (v) {
  try {
//    magnetTrackers = '&tr=' + showtime.httpReq(v).toString().replace(/\n+/g, '&tr=');
    magnetTrackers = '&tr=' + http.request(v).toString().replace(/\n+/g, '&tr=');
  }
  catch (e) {
  }
});
*/
/*
*/
/*
//function setPageHeader(page, title) {
function setPageHeader(page, title, icon) {
  if (!service.tosaccepted) {
    if (popup.message(tos, true, true)) {
      service.tosaccepted = 1;
    }
    else {
//      page.error('TOS not accepted. plugin disabled');
      page.error('Условия не приняты. Плагин отключен.');
      return;
    }
  }
*/
/*
  if (!logged)
//    login(page, true);
    login(page, false);
*/
/*
  page.loading = true;
  if (page.metadata) {
    page.metadata.background = LOGOBACKGROUND;
    page.metadata.logo = LOGO;
    page.metadata.icon = LOGO;
//    page.metadata.title = PREFIX;
//    page.metadata.title = title;
    page.metadata.title = TTL;
//    page.metadata.title = showtime.entityDecode(title);
//    page.metadata.title = new showtime.RichText(title);
//    page.metadata.title = new RichText(title);
  }
  page.type = 'directory';
//  page.model.contents = 'list';
//  page.model.contents = 'grid';
  page.contents = 'items';
  page.loading = false;
};
*/
//plugin.addURI(PREFIX + ':start', function (page) {
new page.Route(PREFIX + ':start', function (page) {
  if (!service.tosaccepted) {
    if (popup.message(tos, true, true)) {
      service.tosaccepted = 1;
    } 
    else {
//      page.error('TOS not accepted. plugin disabled');
      page.error('Условия не приняты. Плагин отключен.');
      return;
    }
  }
/*
  log.d('ddddddddddddddddddddddddddddddddddd');
  log.d('ddddddd' + BASE_URL + 'ddddddd');
  log.d('ddddddddddddddddddddddddddddddddddd');
  resp = http.request(BASE_URL, {
    caching: true,
    cacheTime: 6000,
    headers: {
//!~del''      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*''/''*;q=0.8,application/signed-exchange;v=b3',
      'User-Agent': UA,
      'Accept-Encoding': 'gzip, deflate, br',
    },
  }).toString();
//  needlogin = /\?do=register/.test(resp);
//  console.log(resp);
//  login(needlogin);
*/
/*
  if (!logged)
//    login(page, true);
    login(page, false);
*/
  var response = http.request(BASE_URL, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0.2 Safari/604.4.7',
    },
    noFail: true,
  });
  if (response.statuscode === 503) {
    m = /var s,t,o,p,b,r,e,a,k,i,n,g,f, ([^;]+)[\s\S]+?challenge-form'\)[\s\S]+?;(.*?.toFixed\(10\);)/.exec(response);
    t = BASE_URL;
    r = t.match(/https?:\/\//)[0];
    t = t.substr(r.length);
    t = t.substr(0, t.length - 1);
    console.log(eval(m[1]));
    console.log(eval(m[2].replace('a.value', 'jschl_answer')));
    console.log(jschl_answer);
    url = /action="\/([^"]+)/.exec(response)[1];
    pass = /name="pass" value="([^"]+)/.exec(response)[1];
    r = /name="r" value="([^"]+)/.exec(response)[1];
    jschl_vc = /name="jschl_vc" value="([^"]+)/.exec(response)[1];
    postdata = {
      r: r,
      jschl_vc: jschl_vc,
      pass: pass,
      jschl_answer: jschl_answer,
    };
    setTimeout(function () {
      var resp = http.request(BASE_URL, {
        'debug': 1,
        'postdata': postdata,
        'headers': {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
          'accept-language': 'ru,en-US;q=0.9,en;q=0.8,zh;q=0.7',
          'cache-control': 'no-cache',
          'content-type': 'application/x-www-form-urlencoded',
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0.2 Safari/604.4.7',
          'upgrade-insecure-requests': '1',
        },
      });
    }, 4000);
  }
  var v = getKeys(response);
//  v = {'file3_separator': '//_//',
//    'bk0': '$$#!!@#!@##', // 11
//    'bk1': '^^^!@##!!##', // 11
//    'bk2': '####^!!##!@@', // 12
//    'bk3': '@@@@@!##!^^^', // 12
//    'bk4': '$$!!@$$@^!@#$$@', // 15
//  };
  log.d({'file3_separator': v.file3_separator, 'bk0': v.bk0, 'bk1': v.bk1, 'bk2': v.bk2, 'bk3': v.bk3, 'bk4': v.bk4});
  service.keys = {'file3_separator': v.file3_separator, 'bk0': v.bk0, 'bk1': v.bk1, 'bk2': v.bk2, 'bk3': v.bk3, 'bk4': v.bk4};
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
//  setPageHeader(page, TTL);
  page.metadata.logo = LOGO;
  page.metadata.icon = LOGO;
//  page.metadata.title = PREFIX;
//  page.metadata.title = title;
  page.metadata.title = TTL;
  page.type = 'directory';
  page.model.contents = 'list';
//  page.model.contents = 'grid';
//  page.appendItem(PREFIX + ':search:', 'search', {title: 'Search ' + PREFIX});
//  page.appendItem(PREFIX + ':search:', 'search', {title: 'Поиск на ' + PREFIX});
  page.appendItem(PREFIX + ':search:', 'search', {title: 'Поиск на ' + BASE_URL});
//  page.appendItem(PREFIX + ':search:', 'search', {title: 'Поиск на ' + PREFIX + ' (' + BASE_URL + ')'});
//  navmenu = document.getElementById('topnav-menu')
//  for (i = 0;  i < navmenu.children.length; i++) {
//    e = navmenu.children[i]
//    href = e.getElementsByClassName('b-topnav__item-link')[0].attributes[1].textContent;
//    title = e.getElementsByClassName('b-topnav__item-link')[0].textContent.trim();
//    console.log('page.appendItem(PREFIX + ":list:' + href + ':' + title + '", "directory", {title: "' + title + '"});')
//    console.log("page.appendItem(PREFIX + ':list:' + href + ':' + title + '', 'directory', {title: '' + title + ''});")
//  }
/*
  page.appendItem(null, 'separator', {title: 'Главная'});
  page.appendItem(PREFIX + ':list:/continue/:Досмотреть', 'directory', {title: 'Досмотреть', icon: LOGOARROW});
  page.appendItem(PREFIX + ':list:/favorites/:Закладки', 'directory', {title: 'Закладки', icon: LOGOARROW});
  page.appendItem(PREFIX + ':list:/?filter=watching:Сейчас смотрят', 'directory', {title: 'Сейчас смотрят', icon: LOGOARROW});
  page.appendItem(PREFIX + ':list:/?filter=popular:Популярные', 'directory', {title: 'Популярные', icon: LOGOARROW});
*/
  page.appendItem(PREFIX + ':list:/?filter=last:Последние поступления', 'directory', {title: 'Последние поступления', icon: LOGOARROW});
//  page.appendItem(PREFIX + ':updates:/:Горячие обновления сериалов', 'directory', {title: 'Горячие обновления сериалов'});
  page.appendItem(PREFIX + ':updates:/:Горячие обновления сериалов', 'directory', {title: 'Горячие обновления сериалов', icon: LOGOARROW});
//  page.appendItem(PREFIX + ':list:/new/:Новинки', 'directory', {title: 'Новинки'});
  page.appendItem(PREFIX + ':list:/new/:Новинки', 'directory', {title: 'Новинки', icon: LOGOARROW});
/*
  page.appendItem(PREFIX + ':list:/?filter=soon:В ожидании', 'directory', {title: 'В ожидании', icon: LOGOARROW});
*/
//  page.appendItem(PREFIX + ':list:/announce/:Анонсы', 'directory', {title: 'Анонсы'});
  page.appendItem(PREFIX + ':list:/announce/:Анонсы', 'directory', {title: 'Анонсы', icon: LOGOARROW});
//  page.appendItem(PREFIX + ':list:/films/:Фильмы', 'directory', {title: 'Фильмы'});
  page.appendItem(PREFIX + ':list:/films/:Фильмы', 'directory', {title: 'Фильмы', icon: LOGOARROW});
//  page.appendItem(PREFIX + ':list:/series/:Сериалы', 'directory', {title: 'Сериалы'});
  page.appendItem(PREFIX + ':list:/series/:Сериалы', 'directory', {title: 'Сериалы', icon: LOGOARROW});
//  page.appendItem(PREFIX + ':list:/cartoons/:Мультфильмы', 'directory', {title: 'Мультфильмы'});
  page.appendItem(PREFIX + ':list:/cartoons/:Мультфильмы', 'directory', {title: 'Мультфильмы', icon: LOGOARROW});
//  page.appendItem(PREFIX + ':list:/animation/:Аниме', 'directory', {title: 'Аниме'});
  page.appendItem(PREFIX + ':list:/animation/:Аниме', 'directory', {title: 'Аниме', icon: LOGOARROW});
//  page.appendItem(PREFIX + ':list:/show/:Передачи и шоу', 'directory', {title: 'Передачи и шоу'});
  page.appendItem(PREFIX + ':list:/show/:Передачи и шоу', 'directory', {title: 'Передачи и шоу', icon: LOGOARROW});
/*
  page.appendItem(PREFIX + ':list:/collections/:Подборки', 'directory', {title: 'Подборки', icon: LOGOARROW});
  page.appendItem(null, 'separator', {title: 'Подборки'});
  page.appendItem(PREFIX + ':list:/collections/1876-multfilmy-netflix/:Мультфильмы Netflix', 'directory', {title: 'Мультфильмы Netflix', icon: LOGOARROW});
*/
  page.loading = false;
});
//plugin.addURI(PREFIX + ':search:(.*)', function (page, query) {
new page.Route(PREFIX + ':search:(.*)', function (page, query) {
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
//  setPageHeader(page, 'Search results for: ' + query + ' (' + page.entries + ')');
//  setPageHeader(page, 'Результаты поиска для: ' + query + ' (' + page.entries + ')');
//  setPageHeader(page, 'Search results for: ' + query);
//  setPageHeader(page, 'Результаты поиска для: ' + query);
//  page.metadata.logo = LOGO;
//  page.metadata.icon = LOGO;
//  page.metadata.title = 'Search results for: ' + query + ' (' + page.entries + ')';
//  page.metadata.title = 'Результаты поиска для: ' + query + ' (' + page.entries + ')';
//  page.metadata.title = 'Search results for: ' + query;
  page.metadata.title = 'Результаты поиска для: ' + query;
  page.type = 'directory';
//  page.model.contents = 'list';
  page.model.contents = 'grid';
  page.entries = 0;
  browse.searcher(page, {
    href: '/search/?do=search&subaction=search&q=' + encodeURIComponent(query),
    title: PREFIX + ' - ' + query,
  });
  page.loading = false;
});
//plugin.addSearcher(PREFIX, LOGO, function (page, query) {
//new page.Searcher(PREFIX, LOGO, function (page, query) {
//plugin.addSearcher(PREFIX + ' - Result', LOGO, function (page, query) {
//new page.Searcher(PREFIX + ' - Result', LOGO, function (page, query) {
//plugin.addSearcher(TTL + ': Result', LOGO, function (page, query) {
//new page.Searcher(TTL + ': Result', LOGO, function (page, query) {
//plugin.addSearcher(PREFIX + ' - результат', LOGO, function (page, query) {
//new page.Searcher(PREFIX + ' - результат', LOGO, function (page, query) {
//plugin.addSearcher(TTL + ': результат', LOGO, function (page, query) {
new page.Searcher(TTL + ': результат', LOGO, function (page, query) {
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
//  setPageHeader(page, TTL);
//  setPageHeader(page, TTL + ': результат');
//  page.metadata.logo = LOGO;
//  page.metadata.icon = LOGO;
//  page.metadata.title = TTL;
  page.metadata.title = TTL + ': результат';
  page.type = 'directory';
//  page.model.contents = 'list';
  page.model.contents = 'grid';
  page.entries = 0;
  browse.searcher(page, {
    href: '/search/?do=search&subaction=search&q=' + encodeURIComponent(query),
    title: PREFIX + ' - ' + query,
  });
  page.loading = false;
});
//plugin.addURI(PREFIX + ':list:(.*):(.*)', function (page, href, title) {
new page.Route(PREFIX + ':list:(.*):(.*)', function (page, href, title) {
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
//  setPageHeader(page, href);
//  setPageHeader(page, title);
//  setPageHeader(page, params.title);
//  setPageHeader(page, TTL);
  page.metadata.logo = LOGO;
  page.metadata.icon = LOGO;
//  page.metadata.title = href;
//  page.metadata.title = title;
//  page.metadata.title = params.title;
//  page.metadata.title = TTL;
  page.type = 'directory';
//  page.model.contents = 'list';
  page.model.contents = 'grid';
  browse.list(page, {
    href: href,
    title: title,
  });
  page.loading = false;
});
//plugin.addURI(PREFIX + ':updates:(.*):(.*)', function (page, href, title) {
new page.Route(PREFIX + ':updates:(.*):(.*)', function (page, href, title) {
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
//  setPageHeader(page, href);
//  setPageHeader(page, title);
//  setPageHeader(page, params.title);
//  setPageHeader(page, TTL);
  page.metadata.logo = LOGO;
  page.metadata.icon = LOGO;
//  page.metadata.title = href;
//  page.metadata.title = title;
//  page.metadata.title = params.title;
//  page.metadata.title = TTL;
  page.type = 'directory';
  page.model.contents = 'list';
//  page.model.contents = 'grid';
  browse.updates(page, {
    href: href,
    title: title,
  });
  page.loading = false;
});
//plugin.addURI(PREFIX + ':moviepage:(.*)', function (page, data) {
new page.Route(PREFIX + ':moviepage:(.*)', function (page, data) {
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
//  setPageHeader(page, data.title);
//  setPageHeader(page, TTL);
//  page.metadata.logo = data.icon;
//  page.metadata.logo = LOGO;
//  page.metadata.icon = data.icon;
//  page.metadata.icon = LOGO;
//  page.metadata.title = data.title;
//  page.metadata.title = TTL;
  page.type = 'directory';
  page.model.contents = 'list';
//  page.model.contents = 'grid';
  moviepage.contentPage(page, data);
  page.loading = false;
});
//plugin.addURI(PREFIX + ':SEASON:(.*)', function (page, data) {
new page.Route(PREFIX + ':SEASON:(.*)', function (page, data) {
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
//  setPageHeader(page, data.title);
//  setPageHeader(page, TTL);
//  page.metadata.logo = data.icon;
//  page.metadata.logo = LOGO;
//  page.metadata.icon = data.icon;
//  page.metadata.icon = LOGO;
//  page.metadata.title = data.title;
//  page.metadata.title = TTL;
  page.type = 'directory';
  page.model.contents = 'list';
//  page.model.contents = 'grid';
  browse.season(page, data);
  page.loading = false;
});
//'play:data': {
//  'id': '39707',
//  'translator_id': '88',
//  'title': 'Безумен, но не болен',
//  'icon': 'https://static.hdrezka.ac/i/2021/5/19/pb6235e2c13f4yz70d37i.png'
//  'type': 'movie',
//  'camrip': '0',
//  'ads': '0',
//  'director': '0',
//  'cdn_url': 0,
//  'type': 'serial',
//  season: data.season_id,
//  episode: data.episode_id,
//}
//plugin.addURI(PREFIX + ':play:(.*)', function (page, data) {
new page.Route(PREFIX + ':play:(.*)', function (page, data) {
  var canonicalUrl = PREFIX + ':play:' + data;
  page.loading = true;
  page.metadata.background = LOGOBACKGROUND;
  page.type = 'directory';
//  page.type = 'video';
  data = JSON.parse(data);
  log.d({
    'play:data': data,
  });
  if (!data.cdn_url) {
    if (data.translator_id) {
      postdata = {
        id: data.id,
        translator_id: data.translator_id,
        season: data.season_id,
        episode: data.episode_id,
        action: 'get_stream',
      };
    }
    if (data.type == 'movie') {
      postdata = {
        id: data.id,
        translator_id: data.translator_id,
        is_camrip: data.camrip ? data.camrip : 0,
        is_ads: data.ads ? data.ads : 0,
        is_director: data.director ? data.director : 0,
        action: 'get_movie',
      };
    }
    log.d({
      postdata: postdata,
    });
    resp = http.request(BASE_URL + '/ajax/get_cdn_series/?t=' + new Date().getTime(), {
      'debug': 1,
//      arg: {t: new Date().getTime()},
      'headers': {
        'origin': BASE_URL,
        'accept-encoding': 'gzip, deflate',
        'accept-language': 'ru,en-US;q=0.9,en;q=0.8,zh;q=0.7',
        'x-requested-with': 'XMLHttpRequest',
//        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36',
        'user-agent': UA,
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'accept': '*/*',
      },
      'referrer': BASE_URL,
      'postdata': postdata,
    });
    log.d(resp.toString());
    resp = JSON.parse(resp);
//    streams = resp.url;
    streams = clearUrl(resp.url);
    data.subtitle = resp.subtitle;
  }
  else streams = data.cdn_url;
//  dom = html.parse('<html><body>' + seasons + episodes + '</body></html>').root;
  var videoparams = {
    canonicalUrl: canonicalUrl,
    no_fs_scan: true,
    icon: data.icon,
    title: data.title,
    year: data.year ? data.year : 0,
    season: data.season ? data.season : -1,
    episode: data.episode ? data.episode : -1,
    sources: [{
      url: [],
    }],
//    subtitles: [{
//      url: resp.subtitle.match(/(\[.*\])(.*)/)[2],
//      language: resp.subtitle.match(/(\[.*\])(.*)/)[1],
//      title: resp.subtitle.match(/(\[.*\])(.*)/)[1],
//    }],
  };
  list = scrapeSourceLinks(streams);
  videoparams.subtitles = scrapeSourceSub(data.subtitle);
  try {
//    videoparams.subtitles.push({
//      url: BASE_URL + element.attributes.getNamedItem('src').value,
//      language: element.attributes.getNamedItem('srclang').value,
//      title: element.attributes.getNamedItem('src').value.match(/file\/\d+\/([^']+)/)[1],
//    });
    for (i = 0; i < list.length; i++) {
      if (list[i].hls) {
        videoparams.sources = [{
          url: 'hls:' + list[i].hls,
        }];
        video = 'videoparams:' + JSON.stringify(videoparams);
        log.d(video);
        log.d(videoparams.canonicalUrl == (PREFIX + ':play:' + JSON.stringify(data)));
        log.d(data);
        page.appendItem(video, 'item', {
          title: 'HLS ' + list[i].q + ' | ' + data.title,
          description: '',
          icon: data.icon,
        });
        page.entries++;
      }
    }
  }
  catch (error) {
    log.e('oshibka pri vyvode variantov m3u8');
    log.e(error.stack);
  }
  try {
    for (i = 0; i < list.length; i++) {
      if (list[i].mp4) {
        videoparams.sources = [{
          url: list[i].mp4,
        }];
        video = 'videoparams:' + JSON.stringify(videoparams);
        log.d(video);
        log.d(videoparams.canonicalUrl == (PREFIX + ':play:' + JSON.stringify(data)));
        log.d(data);
        page.appendItem(video, 'item', {
          title: 'MP4 ' + list[i].q + ' | ' + data.title,
          description: '',
          icon: data.icon,
        });
        page.entries++;
      }
    }
  }
  catch (error) {
    log.d('oshibka v MP4');
    log.d(error.stack);
  }
//  null != this.options.subtitles && (r = [], null != this.options.subtitles.master_vtt && r.push({
//    on_start: !0,
//    srclang: 'ru',
//    label: 'Russian',
//    src: this.options.subtitles.master_vtt,
//  }),
//  null != this.options.subtitles.slave_vtt && r.push({
//    srclang: 'en',
//    label: 'English',
//    src: this.options.subtitles.slave_vtt,
//~  }));
//~}
  page.loading = false;
});
function getKeys(response) {
  var playerjs = /src="(\/templates\/.*?playerjs[^"]+)/.exec(response.toString())[1];
  var packed = http.request(BASE_URL+playerjs, {
    headers: {
      'Referer': BASE_URL,
      'User-Agent': UA,
    }}).toString();
  var unpacked = DeanEdwardsUnpacker.unpack(packed);
  match = /u:.*?'([^']+)[\s\S]+?y:.*?'([^']+)/g.exec(unpacked);
  o = {};
  o.y = match[2];
  u = match[1];
  var dechar = function (x) {
    return String.fromCharCode(x);
  };
  var abc = String.fromCharCode(65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122);
  var salt = {
    _keyStr: abc + '0123456789+/=',
    e: function (e) {
      var t = '';
      var n; var r; var i; var s; var o; var u; var a;
      var f = 0;
      e = salt._ue(e);
      while (f < e.length) {
        n = e.charCodeAt(f++);
        r = e.charCodeAt(f++);
        i = e.charCodeAt(f++);
        s = n >> 2;
        o = (n & 3) << 4 | r >> 4;
        u = (r & 15) << 2 | i >> 6;
        a = i & 63;
        if (isNaN (r)) {
          u = a = 64;
        }
        else
        if (isNaN (i)) {
          a = 64;
        }
        t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a);
      }
      return t;
    },
    d: function (e) {
      var t = '';
      var n; var r; var i;
      var s; var o; var u; var a;
      var f = 0;
      e = e.replace(/[^A-Za-z0-9\+\/\=]/g, '');
      while (f < e.length) {
        s = this._keyStr.indexOf(e.charAt(f++));
        o = this._keyStr.indexOf(e.charAt(f++));
        u = this._keyStr.indexOf(e.charAt(f++));
        a = this._keyStr.indexOf(e.charAt(f++));
        n = s << 2 | o >> 4;
        r = (o & 15) << 4 | u >> 2;
        i = (u & 3) << 6 | a;
        t = t + dechar(n);
        if (u != 64) {
          t = t + dechar(r);
        }
        if (a != 64) {
          t = t + dechar(i);
        }
      }
      t = salt._ud(t);
      return t;
    },
    _ue: function (e) {
      e = e.replace(/\r\n/g, '\n');
      var t = '';
      for (var n = 0; n < e.length; n++) {
        var r = e.charCodeAt(n);
        if (r < 128) {
          t += dechar(r);
        }
        else
        if (r > 127 && r < 2048) {
          t += dechar(r >> 6 | 192);
          t += dechar(r & 63 | 128);
        }
        else {
          t += dechar(r >> 12 | 224);
          t += dechar(r >> 6 & 63 | 128);
          t += dechar(r & 63 | 128);
        }
      }
      return t;
    },
    _ud: function (e) {
      var t = '';
      var n = 0;
      var r = 0;
      var c1 = 0;
      var c2 = 0;
      while (n < e.length) {
        r = e.charCodeAt(n);
        if (r < 128) {
          t += dechar(r);
          n++;
        }
        else
        if (r > 191 && r < 224) {
          c2 = e.charCodeAt(n + 1);
          t += dechar((r & 31) << 6 | c2 & 63);
          n += 2;
        }
        else {
          c2 = e.charCodeAt(n + 1);
          c3 = e.charCodeAt(n + 2);
          t += dechar((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
          n += 3;
        }
      }
      return t;
    },
  };
  var pepper = function (s, n) {
    s = s.replace(/\+/g, '#');
    s = s.replace(/#/g, '+');
//    var a = sugar(o.y) * n;
    print(o.y);
    var a = sugar(o.y) * n;
    if (n < 0) {
      a += abc.length / 2;
    }
    var r = abc.substr(a * 2) + abc.substr(0, a * 2);
    return s.replace(/[A-Za-z]/g, function(c) {
      return r.charAt(abc.indexOf(c));
    });
  };
  var sugar = function (x) {
    x = x.split(dechar(61));
    var result = '';
    var c1 = dechar(120);
    var chr;
    for (var i in x) {
      if (x.hasOwnProperty(i)) {
        var encoded = '';
        for (var j in x[i]) {
          if (x[i].hasOwnProperty(j)) {
            encoded += (x[i][j] == c1) ? dechar(49) : dechar(48);
          }
        }
        chr = parseInt (encoded, 2);
        result += dechar(chr.toString(10));
      }
    }
    return result.substr(0, result.length - 1);
  };
  var decode = function (x) {
    if (x.substr(0, 2) == '#1') {
      return salt.d(pepper(x.substr(2), -1));
    }
    else
    if (x.substr(0, 2) == '#0') {
      return salt.d(x.substr(2));
    }
    else {
      return x;
    }
  };
  u = /u:.*?'([^']+)/gm.exec(unpacked)[1];
  return (JSON.parse(decode(u)));
};
function clearUrl(url) {
  log.d(service.keys);
  url = fd2(url);
  function fd2(x) {
    var a;
    a = x.substr(2);
    for (var i = 4; i > -1; i--) {
      if (exist(service.keys['bk' + i])) {
        if (service.keys['bk' + i] != '') {
          a = a.replace(service.keys.file3_separator + b1(service.keys['bk' + i]), '');
        }
      }
    }
    try {
      a = b2(a);
    }
    catch (e) {
      a = '';
    }
    function b1(str) {
//      console.log(unescape(str));
      return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
          function toSolidBytes(match, p1) {
            return String.fromCharCode('0x' + p1);
          }));
    }
    function b2(str) {
      return decodeURIComponent(atob(str).split('').map(function (c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
    }
    return a;
  }
  return url;
};
function scrapeSourceLinks(streams) {
  var returnValue = [];
//  var regex = /(\[.\d+p.*?\])(.*?) or (.*?\d+.mp4)/gm;
  var regex = /(\[.\d+p.*?\])(.*?) or (.*?\.*?\.mp4)/gm;
  while ((m = regex.exec(streams)) !== null) {
//    console.log(m);
    if (m.index === regex.lastIndex) {
      regex.lastIndex++;
    }
    returnValue.push({
      q: m[1],
      hls: m[2],
      mp4: m[3],
    });
  }
  return returnValue;
};
function scrapeSourceSub(streams) {
  var returnValue = [];
//  var regex = /(\[.\d+p.*?\])(.*?) or (.*?\d+.mp4)/gm;
  var regex = /(\[.*?\])(.*?vtt)/gm;
  while ((m = regex.exec(streams)) !== null) {
//    console.log(m);
    if (m.index === regex.lastIndex) {
      regex.lastIndex++;
    }
    returnValue.push({
      language: m[1],
      url: m[2],
      title: m[1],
    });
  }
  return returnValue;
};
function oprint(o) {print(JSON.stringify(o, null, 4))};
function d(sBase64) {return String(Duktape.dec('base64', sBase64))};
var exist = function (x) {
  return x != null && typeof (x) != 'undefined' && x != 'undefined';
};
//})(this);