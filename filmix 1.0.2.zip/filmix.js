(function (plugin) {
var logo = plugin.path + "logo.png";
var background = plugin.path + "back.jpg";
var pluginDescriptor = plugin.getDescriptor();
var service = plugin.createService(pluginDescriptor.title, pluginDescriptor.id + ":start", "video", true, logo);
var items = [];
var http = require('showtime/http');
var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36';
		
var settings = plugin.createSettings(plugin.getDescriptor().id, logo, plugin.getDescriptor().synopsis);
var storage = plugin.createStore('filmix');
											
var links_for_serials = [];

													
	function setPageHeader(page, title, icon) {
		page.type = "directory";
		page.contents = "items";
		page.metadata.logo = logo;
		page.metadata.icon = logo;
		page.metadata.title = new showtime.RichText(title);
		page.metadata.background = background;
	}


plugin.addURI(plugin.getDescriptor().id + ":start", function (page) {
	setPageHeader(page, plugin.getDescriptor().synopsis);
	page.loading = true;
	var category = [
	{name:'Новинки', url: 'list?sort=date&'},
	{name:'Популярное', url: 'popular?'},
	{name:'Сейчас смотрят', url: 'viewing?'},
	{name:'Фильмы', url: 'list?category=s0&sort=date&'},
	{name:'Сериалы', url: 'list?category=s7&sort=date&'},
	{name:'Мультфильмы', url: 'list?category=s14&sort=date&'},
	{name:'Мультсериалы', url: 'list?category=s714-s93&sort=date&'},
	{name:'Телепередачи', url: 'list?category=s7-s14-s714-s93-s999-s0&genre=g16-g95-g98-g99&sort=date&'},
	{name:'Аниме', url:'list?category=s7-s14-s714-s93-s999-s0&genre=g21&sort=date&'},
	
	];
	
	category.forEach(function(data, index) {
		
		page.appendItem(plugin.getDescriptor().id + ":list:" + data.url+'~'+data.name, "directory", {
					title:  data.name,					
		});
		
	});
	page.loading = false;
});


plugin.addURI(plugin.getDescriptor().id + ":list:(.*)~(.*)", function (page, mid_url, page_title) {
		setPageHeader(page, plugin.getDescriptor().synopsis+': '+page_title);
		page.loading = true;
		page.metadata.logo = logo;
		pageNum=0;
		page.model.contents = 'grid';
		page.entries = 0;
		function load(){			
			var doc = sendRequest('http://5.61.48.15/partner_api/'+mid_url+'page='+pageNum);	
			doc = showtime.JSONDecode(doc);
			
			for (i = 0; i < doc.items.length; i++) {
				 var item = doc.items[i];
				 var title = item.title;
				 if(item.title!==item.original_title && item.original_title){
				  title = item.title+"|"+item.original_title;
				 }
				 
				 

				 page.appendItem(plugin.getDescriptor().id + ":open" + item.id +'~'+title+'~'+item.poster, "video", {
					title:  title ,
					icon: item.poster,
					id:item.id
					});
				  
			 }
			 page.entries++;
			 pageNum++;
			 page.haveMore(true);
		
		}
		load();
		page.asyncPaginator = load;
		page.loading = false;
	});

plugin.addURI(plugin.getDescriptor().id + ":open(.*)~(.*)~(.*)", function (page, id, title, img) {
	

	var detail_url = 'http://5.61.48.15/partner_api/film/'+id+'/details';
	var links_url = 'http://5.61.48.15/partner_api/video_links/'+id;
	var images = 'http://5.61.48.15/partner_api/film/139029/images';
	
	
	setPageHeader(page, plugin.getDescriptor().synopsis+': '+title);
	page.loading = true;
	var detail = showtime.JSONDecode(sendRequest(detail_url));	
	var links = showtime.JSONDecode(sendRequest(links_url));		 		
	
	 if (links.length > 0){
		
		 for (i = 0; i < links.length; i++) {		 
			 	
				var description = detail.short_story;
				var roles = getStringFromArray(detail.actors);
				var genre = getStringFromArray(detail.genres);
				description = description + "<br><br><b>В ролях</b>:"+roles+"<br><br><b>Жанр</b>:"+genre+"<br>";
			
			if(links[i].seasons){	
				var seasons = links[i].seasons;
				links_for_serials = links;
				
				page.appendItem(plugin.getDescriptor().id + ":seasons:"+img+"~"+i, "video", {
					title: links[i].name,
					icon: img,	
					description:  new showtime.RichText(description),
					duration: detail.duration,
					year: detail.year,
					genre: genre,
					rating: detail.ratingImdb*10,				
					tagline: detail.slogan,	
				});			 
			
			} else {
				
			    var files = links[i].files;				
			
				
				page.appendItem(plugin.getDescriptor().id + ":types:" + showtime.JSONEncode(files) + "~" + img, 'video', {
					title: links[i].name,
					icon: img,	
					description:  new showtime.RichText(description),
					duration: detail.duration,
					year: detail.year,
					genre: genre,
					rating: detail.ratingImdb*10,				
					tagline: detail.slogan,
				});	
			}
			
			
			
		
		 }
		 
		 
			page.appendItem('', 'separator', {
					title: 'Актеры:',
			});
			
			detail.actors.forEach(function(data, index) {
				console.log(data.id);
				page.appendItem(plugin.getDescriptor().id + ":actor:" + data.id +'~'+data.name , 'directories', {
					title: data.name,
					icon: 'https://filmix.ink/uploads/persons/thumbs/w220/'+data.id+'.jpg',
				});	
			
			});
		
	}
	
	
	page.loading = false;
	
});


plugin.addURI(plugin.getDescriptor().id + ":actor:(.*)~(.*)", function (page, id, name) {
	setPageHeader(page, name);
	page.loading = true;
	var persons_url = 'http://5.61.48.15/partner_api/person/'+id.toLowerCase();
	var person_data = showtime.JSONDecode(sendRequest(persons_url));		
	
	if(typeof person_data.actor != "undefined"){
		for (i = 0; i < person_data.actor.length; i++) {
					 var item = person_data.actor[i];
					 var title = item.title;
					 if(item.title!==item.original_title && item.original_title){
					  title = item.title+"|"+item.original_title;
					 }
					 
					 

					 page.appendItem(plugin.getDescriptor().id + ":open" + item.id +'~'+title+'~'+item.poster, "video", {
						title:  title ,
						icon: item.poster,
						id:item.id
						});
					  
		}
	} else {
			page.appendItem('', 'separator', {
					title: 'Список фильмов по актеру не найден',
			});
	}
	
	page.loading = false;
	
});



plugin.addURI(plugin.getDescriptor().id + ":types:(.*)~(.*)", function (page, list, img) {
	setPageHeader(page, plugin.getDescriptor().synopsis);
	page.loading = true;
	list = showtime.JSONDecode(list);

	 for (i = 0; i < list.length; i++) {							
			 page.appendItem(list[i]['url'], 'directory', {
				title: list[i]['quality'],
				icon: img,
			});	
		
		 }
		 
		 page.loading = false;
	
});


plugin.addURI(plugin.getDescriptor().id + ":seasons:(.*)~(.*)", function (page, img, num) {	
		setPageHeader(page, plugin.getDescriptor().synopsis);
		page.loading = true;	
		
		var seasons = links_for_serials[num].seasons;
		
		 for (i = 0; i < seasons.length; i++) {			

			var season_name = "Сезон "+seasons[i].season;						
			page.appendItem(plugin.getDescriptor().id + ":series:" + img + "~"+num+"~"+i, 'directory', {
				title: season_name,
				icon: img,
			});
			
		}

		 
		 page.loading = false;
	
});



plugin.addURI(plugin.getDescriptor().id + ":series:(.*)~(.*)~(.*)", function (page, img, num, s) {
	setPageHeader(page, plugin.getDescriptor().synopsis);
	page.loading = true;	

	var episodes = links_for_serials[num].seasons[s].episodes;
	
	for(var index in episodes) {
		
		var val = episodes[index];
		var ep_name = 'Серия '+val.episode;
		if(val.title){
			ep_name= ep_name+": "+val.title;
		}
		var files = val.files;	
				
		page.appendItem(plugin.getDescriptor().id + ":types:" + showtime.JSONEncode(files) + "~" + img, 'directory', {
			title: ep_name,
			icon: img,				
		});	
		
	}

		 
	page.loading = false;
	
});


plugin.addSearcher(plugin.getDescriptor().id, logo, function (page, query) {
	page.entries = 0;
	var fromPage = 0,
	tryToSearch = true;	
	page.loading = true;
	page.model.contents = 'grid';
	var encoded = query;
	//var encoded = encodeURI(query);
	

	var v = sendRequest("http://5.61.48.15/partner_api/list?search="+query+"&sort=news_read&page=0");

	var doc = showtime.JSONDecode(v);
	
	if (doc.items.length > 0) {
			page.entries = doc.items.length;
			for (var i = 0; i < doc.items.length; i++) {
				
				 var item = doc.items[i];
						
				 page.appendItem(plugin.getDescriptor().id + ":open" + item.id +'~'+item.title+'~'+item.poster, "video", {
					title: item.title ,
					icon:item.poster,
					id:item.id
					});
			}	
	}
	
	
	page.loading = false;
	tryToSearch = false;
	
	});
	
	function sendRequest(url){
		
		var token_def = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiIsImp0aSI6ImZ4LTVlYjg3NzgwMjY5MWMifQ.eyJpc3MiOiJodHRwczpcL1wvZmlsbWl4Lm1lIiwiYXVkIjoiaHR0cHM6XC9cL2ZpbG1peC5tZSIsImp0aSI6ImZ4LTVlYjg3NzgwMjY5MWMiLCJpYXQiOjE1ODkxNDc1MjAsIm5iZiI6MTU4OTEzNjcyMCwiZXhwIjoxNTkxNzM5NTIwLCJwYXJ0bmVyX2lkIjoiMiIsImhhc2giOiJiOTMwZDhjMGMzOTE5ZDZkNDBjYWE4ZWExODY0ODFmODVjNGVlNjA4IiwidXNlcl9pZCI6bnVsbCwiaXNfcHJvIjpmYWxzZSwiaXNfcHJvX3BsdXMiOmZhbHNlLCJzZXJ2ZXIiOiIifQ.I8NBrVlREjVA_CthL0i6GBTgR6-y7lndU5JLmhh4ejA';
		
		
		var token = token_def;	
	
		if(storage.expired && storage.expired > Math.floor(Date.now() /1000) && storage.token){			
			var token = storage.token;			
		} 
		
		var headers = {
														  debug: false,
														  compression: true,
														  headRequest: false,
														  headers: {
															  'User-Agent': UA,															 
															  'accept': 'application/json, text/javascript, */*; q=0.01',
															  'X-FX-Token': token,
															  
														  },
														  
														};
														
		return showtime.httpReq(url, headers);
		
	}
	
	
	function login(page, showDialog) {
        var text = '';
        if (showDialog) {
           text = 'Введите логин и пароль';
           var logged = false;
        }

        if (!logged && service.authToken.length == 40) {
            credentials = plugin.getAuthCredentials(plugin.getDescriptor().synopsis, text, showDialog);
		
            if (credentials && credentials.username && credentials.password) {
                page.loading = true;
				
				var get_token_header = {
														  debug: false,
														  compression: true,
														  headRequest: false,
														  headers: {
															  'User-Agent': UA,															 
															  'accept': 'application/json, text/javascript, */*; q=0.01',															  
														  },
														  
														  postdata:{
																key:"160c907041cac0fd84c367c1e0031b67",
																token:service.authToken,
																user_name:credentials.username,
																user_passw:credentials.password,
														  }
														  
														};
				
				
                var reply = showtime.httpReq('http://5.61.48.15/partner_api/request_token', get_token_header);
				reply = showtime.JSONDecode(reply);
                page.loading = false;
				if(reply.token && reply.expired){

					storage.token = reply.token;
					storage.expired = reply.expired;
					sendRequest('http://5.61.48.15/partner_api/profile/login');
					logged = true;					
				}
                
            }
        } else if (service.authToken.length != 40) {
			showtime.message("Не верный формат auth token", true, false);
			return false;
		}
        if (showDialog) {
           if (logged) {
				showtime.message("Вход успешно произведен. Параметры входа сохранены.", true, false);	
			}
           else {
			   showtime.message("Не удалось войти. Проверьте auth token/email/пароль...", true, false);
			   }
        }
    }
	
	function logOut(){
		storage.token = false;
		storage.expired = false;
		showtime.message("Выход совершен", true, false);
	}

	
	function getStringFromArray(obj){
				var str = '';
				obj.forEach(function(data, index) {
				  str = str+data.name+',';
				});
			    return str.substring(0, str.length - 1);
	}
	
		settings.createString('authtoken', 'Auth token', '', function(v) {
			service.authToken = v;
		});

		if(!storage.expired || storage.expired < Math.floor(Date.now() /1000) || !storage.token){			
			settings.createAction(plugin.getDescriptor().id+'_login', 'Войти в ' + plugin.getDescriptor().id, function() {		
				login(0, true);        
			});		
		} else {
			settings.createAction(plugin.getDescriptor().id+'_login', 'Выйти из ' + plugin.getDescriptor().id, function() {		
				logOut(0, true);        
			});	
		}
 
			

	

})(this);


