/**
 *  newstudio plugin for Movian
 *
 *  Copyright (C) 2017 Buksa, Michman
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
//ver 0.0.4

// parsit plugin.json
var plugin = JSON.parse(Plugin.manifest);
// PREFIX unikalnyj id plagina
var PREFIX = plugin.id;
//logo beret iz kornevoj papki s plago
var LOGO = Plugin.path + 'logo.png';
// adress sajta
var BASE_URL = 'http://newstudio.tv';
//user agent mestami nuzhno spofit'
var UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36';

var result = '',
  referer = BASE_URL,
  data = {};

//sistemnye biblioteki tak skazat'
var page = require('showtime/page');
var service = require('showtime/service');
var settings = require('showtime/settings');
var io = require('native/io');
var prop = require('showtime/prop');
var popup = require('native/popup');

var http = require('showtime/http');
var html = require('showtime/html');

io.httpInspectorCreate('.*newstudio.tv.*', function (ctrl) {
  ctrl.setHeader('User-Agent', UA);
  ctrl.setHeader('Referer', 'http://newstudio.tv');
});

// Create the service (ie, icon on home screen)
service.create(plugin.title, PREFIX + ':start', 'video', true, LOGO);
// Create the settings
//stranica nastroik plagina
settings.globalSettings('settings', plugin.title, LOGO, plugin.synopsis);
settings.createInfo('info', LOGO, 'Plugin developed by ' + plugin.author + '. \n');
settings.createDivider('Settings:');
settings.createBool('debug', 'Debug', false, function (v) {
  service.debug = v;
});
settings.createString('domain', '\u0414\u043e\u043c\u0435\u043d', 'http://newstudio.tv', function (v) {
  service.domain = v;
});
settings.createBool('bg', 'Background', true, function (v) {
  service.bg = v;
});

// Landing page
//startovay stranica plagina
new page.Route(PREFIX + ':start', function (page) {
  page.type = 'directory';
  page.metadata.title = PREFIX;
  page.metadata.icon = LOGO;

  /// req on base_url
  var resp = http.request(BASE_URL, {
    debug: true,
    noFail: true, // Don't throw on HTTP errors (400- status code)
    compression: true // Will send 'Accept-Encoding: gzip' in request
    // caching: true, // Enables Movian's built-in HTTP cache
    //cacheTime: 3600
  });
  // если в хтмл нет строки логоут
  if (null == /logout/.exec(resp)) {
    //добовляем итем на страницу для вызыва URI HDRezka:login stroka > 161
    page.appendItem(PREFIX + ':login', 'directory', {
      title: 'login'
    });
  } else
    //от обратного
    //добовляем итем на страницу для вызыва URI HDRezka:logout stroka > 202
    page.appendItem(PREFIX + ':logout', 'directory', {
      title: 'logout'
    });

  var list = undefined;

  function loader() {
    if (list == undefined) {
      url = '/tracker.php';
    }

    var resp = http.request(BASE_URL + url, {
      debug: true,
      noFail: true, // Don't throw on HTTP errors (400- status code)
      compression: true // Will send 'Accept-Encoding: gzip' in request
      // caching: true, // Enables Movian's built-in HTTP cache
      //cacheTime: 3600
    });
    page.appendItem(PREFIX  + ":search:", 'search', {
      title: 'Поиск на ' + service.domain
    });
    page.appendItem("", "separator", {
     
     });

    list = ScrapeList(resp);
    populateItemsFromList(page, list);

    url = '/' + list.next;
    page.haveMore(list !== undefined && list.endOfData !== undefined && !list.endOfData);
    page.loading = false;
  }
  loader();
  page.asyncPaginator = loader;
});

/// создаем URI HDRezka:login
new page.Route(PREFIX + ':login', function (page, showAuth, token) {
  // попап с запросом на пороль
  var credentials = popup.getAuthCredentials('NewStUDio.tv', 'Login Required', 1, null, true);
  if (credentials.rejected) return 'Rejected by user';
  //если нет узернаме паса то
  if (credentials.username !== '' && credentials.password !== '') {
    //делаем запрос
    v = http.request('http://newstudio.tv/login.php', {
      //не перенапровлять
      noFollow: true,
      //не выдовать ошибку при 404
      noFail: true,
      //дебаг вывод
      debug: true,
      // пост дата для запроса с
      postdata: {
        //user
        login_username: credentials.username,
        //pass
        login_password: credentials.password,
        autologin: 1,
        login: 1
      },
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.91 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        Referer: 'http://newstudio.tv/index.php',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.8,ru;q=0.6'
      }
    });

    if (v.statuscode == '200') {
      console.log('status 200');
    }
  }
  //redirekt na glavnuu
  page.redirect(PREFIX + ':start');
});
//log out
new page.Route(PREFIX + ':logout', function (page) {
  //тут тело функции
  // поидеи нам тут нужен только запрос на страницу лог оут
  http.request('http://newstudio.tv/login.php?logout=1');
  page.loading = false;
  //redirect na glavnuu
  page.redirect(PREFIX + ':start');
});

new page.Route(PREFIX + ':search:(.*)', function (page, query) {
  page.type = 'directory';
  page.metadata.title = PREFIX;
  page.metadata.icon = LOGO;

  var list;
  var sitesearch;
  //setPageHeader(page, "Результат поиска по запросу : " + query);
  function loader() {
    if (list == undefined) {
      url = '/tracker.php';
      sitesearch = '?nm=';
    }

    var resp = http.request(BASE_URL + url + sitesearch + encodeURIComponent(query), {
      debug: true,
      noFail: true, // Don't throw on HTTP errors (400- status code)
      compression: true // Will send 'Accept-Encoding: gzip' in request
      // caching: true, // Enables Movian's built-in HTTP cache
      //cacheTime: 3600
    });

    list = ScrapeList(resp);
    populateItemsFromList(page, list);
    console.log(encodeURIComponent(BASE_URL + url + sitesearch + encodeURIComponent(query)));
    url = '/' + list.next;
    page.haveMore(list !== undefined && list.endOfData !== undefined && !list.endOfData);
    page.loading = false;
  } 
  loader();
  page.asyncPaginator = loader;
});

page.Searcher(PREFIX + ' - Result', LOGO, function (page, query) {
  page.metadata.icon = LOGO;
  var list;

  function loader() {
    if (list == undefined) {
      url = '/tracker.php';
    }
    var resp = http.request(BASE_URL + url, {
      debug: true,
      noFail: true, // Don't throw on HTTP errors (400- status code)
      compression: true, // Will send 'Accept-Encoding: gzip' in request
      // caching: true, // Enables Movian's built-in HTTP cache
      //cacheTime: 3600
      postdata: {
        max: 1,
        to: 1,
        nm: query
      }
    });

    list = ScrapeList(resp);
    populateItemsFromList(page, list);

    url = '/' + list.next;
    page.haveMore(list !== undefined && list.endOfData !== undefined && !list.endOfData);
    page.loading = false;
  }

  loader();
  page.asyncPaginator = loader;
});

// sozdaem URI newstudio:moviepage:/viewtopic.php?t=25618
new page.Route(PREFIX + ':moviepage:(.*)', function (page, href) {
  page.type = 'directory';
  page.metadata.title = PREFIX;
  page.metadata.icon = LOGO;

  var resp = http.request(BASE_URL + href, {
    debug: true,
    noFail: true, // Don't throw on HTTP errors (400- status code)
    compression: true // Will send 'Accept-Encoding: gzip' in request
    // caching: true, // Enables Movian's built-in HTTP cache
    //cacheTime: 3600
  });
  if (/magnet[^"]+/.exec(resp))
    page.appendItem(/magnet[^"]+/.exec(resp)[0], 'directory', {
      title: 'magnet Link'
    });
  //(/download.php[^"]+/)
  if (/download.php[^"]+/.exec(resp))
    page.appendItem(BASE_URL + '/' + /download.php[^"]+/.exec(resp)[0], 'directory', {
      title: 'torrent Link'
    });

  if (null == /logout/.exec(resp)) {
    //добовляем итем на страницу для вызыва URI HDRezka:login stroka > 161
    page.appendItem(PREFIX + ':login', 'directory', {
      title: 'login'
    });
  }

});

function ScrapeList(resp) {
  var returnValue = [];
  var dom = html.parse(resp).root;
  var items = dom.getElementByClassName('hl-tr');
  for (var i = 0; i < items.length; i++) {

    returnValue.push({
      // document.getElementsByClassName('hl-tr')[0].getElementsByTagName('a')[3].attributes.getNamedItem("href").value
      url: items[i].getElementByTagName('a')[1].attributes.getNamedItem('href').value.replace('./', '/'),
      title: items[i].getElementByTagName('a')[1].textContent,
      icon: items[i].getElementByTagName('img')[0].attributes.getNamedItem('src').value
    });
  }

  var pagination = dom.getElementByClassName('pagination');
  if (pagination.length !== 0) {
    for (var i = 0; i < pagination[0].getElementByTagName('a').length; i++) {
      var e = pagination[0].getElementByTagName('a')[i];

      if (e.textContent == 'Next' || e.textContent == 'След.') {
        returnValue.next = e.attributes.getNamedItem('href').value;
        returnValue.endOfData = false;
      }
    }

    // returnValue.endOfData = pagination[0].children[fr_navigation[0].children.length - 1].nodeName !== 'a';
  } else returnValue.endOfData = true;
  return returnValue;
}

function populateItemsFromList(page, list) {
  for (i = 0; i < list.length; i++) {
    page.appendItem(PREFIX + ':moviepage:' + list[i].url, 'video', {
      title: list[i].title,
      description: list[i].description,
      icon: BASE_URL + list[i].icon,
      logo: list[i].icon
    });
    page.entries++;
  }
}